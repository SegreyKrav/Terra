# Калькулятор на Dear ImGui (Immediate Mode GUI)

Простой калькулятор «Число А / Число Б» с операциями `+ - * /`, собранный
**полностью статически** под Windows: готовый `calculator.exe` запускается
автономно, без поиска внешних DLL (libgcc/libstdc++/winpthread вшиты в exe,
GLFW прилинкована статической библиотекой `libglfw3.a`).

## Состав репозитория

```
main.cpp          — вся логика приложения (ImGui + GLFW/OpenGL3)
Makefile          — сборка статического .exe кросс-компилятором MinGW-w64
imgui/            — Dear ImGui 1.90.9 (включая backend'ы GLFW и OpenGL3)
glfw3-win64/      — GLFW 3.4: заголовки + статическая libglfw3.a (MinGW-w64)
calculator.exe    — уже собранный 64-битный автономный исполняемый файл
```

## Требования к интерфейсу (реализовано в main.cpp)

| Требование | Реализация |
|---|---|
| Immediate Mode интерфейс | Dear ImGui, рендер каждый кадр |
| Окно фиксированного размера | ImGui-окно на весь клиентский регион с флагами `NoResize | NoMove | NoTitleBar | NoCollapse`; пользователь не может его изменить |
| Два поля ввода | `ImGui::InputFloat("Число А", ...)`, `ImGui::InputFloat("Число Б", ...)` |
| Четыре кнопки в ряд | `+`, `-`, `*`, `/` через `ImGui::Button` + `ImGui::SameLine()` |
| Мгновенное вычисление | `Calculate(op)` вызывается в тот же кадр по нажатию, результат пишется в переменную `g_result` |
| Крупный вывод результата | отдельный экземпляр шрифта 48 px (`g_fontBig`) |
| Деление на ноль | если `Б == 0` и нажато `/` — вместо числа крупным **красным** текстом `Ошибка: деление на ноль!` |

Дополнительно: в шрифт по умолчанию загружены кириллические глифы
(`0x0400–0x045F`), иначе русские подписи отображались бы «квадратиками».

## Сборка

### Вариант 1 — Makefile (MinGW-w64 / MSYS2)

```bash
mingw32-make            # -> calculator.exe
mingw32-make clean
```

### Вариант 2 — одна команда g++

```bat
g++ main.cpp imgui/imgui.cpp imgui/imgui_draw.cpp imgui/imgui_tables.cpp ^
    imgui/imgui_widgets.cpp imgui/backends/imgui_impl_glfw.cpp ^
    imgui/backends/imgui_impl_opengl3.cpp -o calculator.exe ^
    -std=c++17 -O2 -Iimgui -Iglfw3-win64/include ^
    -static -static-libgcc -static-libstdc++ ^
    glfw3-win64/lib-mingw-w64/libglfw3.a ^
    -lopengl32 -lgdi32 -luser32 -lshell32 -lwinmm
```

Ключи `-static -static-libgcc -static-libstdc++` — именно они делают exe
автономным: C/C++ рантаймы MinGW вшиваются внутрь, а GLFW линкуется из
статической `.a`, поэтому рядом с exe не нужно класть `libgcc_s_seh-1.dll`,
`libstdc++-6.dll`, `libwinpthread-1.dll` или `glfw3.dll`.

Проверить отсутствие лишних зависимостей можно так:

```bash
objdump -p calculator.exe | grep "DLL Name"
# ожидаем только системные Windows-библиотеки:
#   GDI32.dll  KERNEL32.dll  msvcrt.dll  OPENGL32.dll  SHELL32.dll  USER32.dll
```

Все перечисленные DLL присутствуют в любой системе Windows, то есть exe
работает автономно «из коробки» (нужен лишь стандартный OpenGL 1.3+,
который есть всегда).

## Использование

1. Введите значения в поля «Число А» и «Число Б» (можно крутить колесом мыши
   или вводить текст с клавиатуры).
2. Нажмите кнопку операции — результат сразу появится крупным шрифтом.
3. При делении на ноль вместо числа будет красная надпись
   «Ошибка: деление на ноль!».
