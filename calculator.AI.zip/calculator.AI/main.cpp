// ����������� �� Dear ImGui (Immediate Mode)
// ���������� ����������� ������ ��� Windows (MinGW-w64)

#include "imgui.h"
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"
#include <GLFW/glfw3.h>

#ifdef _WIN32
#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3native.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#include <cstdio>
#include <cmath>
#include <string>

#ifdef _WIN32
static void SetupConsoleUtf8() {
    if (GetFileType(GetStdHandle(STD_OUTPUT_HANDLE)) != FILE_TYPE_CHAR &&
        GetFileType(GetStdHandle(STD_ERROR_HANDLE)) != FILE_TYPE_CHAR) {
        return;
    }
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_THREAD_ACP);
}

static std::wstring Utf8ToWide(const char* utf8) {
    if (!utf8 || !*utf8) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, utf8, -1, nullptr, 0);
    std::wstring w(static_cast<size_t>(n > 0 ? n - 1 : 0), L'\0');
    if (n > 0) {
        MultiByteToWideChar(CP_UTF8, 0, utf8, -1, &w[0], n);
    }
    return w;
}

static std::string GetSystemFontPath(const char* fontFileName) {
    char winDir[MAX_PATH] = "C:\\Windows";
    GetWindowsDirectoryA(winDir, MAX_PATH);
    return std::string(winDir) + "\\Fonts\\" + fontFileName;
}
#else
static inline void SetupConsoleUtf8() {}
static std::string GetSystemFontPath(const char* fontFileName) {
    return std::string("/usr/share/fonts/") + fontFileName;
}
#endif

// ��������� ������������
static float g_numA = 0.0f;
static float g_numB = 0.0f;
static float g_result = 0.0f;
static bool g_hasResult = false;
static bool g_divError = false;
static char g_lastOp = '+';
static std::string g_historyExpr;

// ������
static ImFont* g_font = nullptr;
static ImFont* g_fontBig = nullptr;
static ImFont* g_fontErr = nullptr;

static void ClearAll() {
    g_numA = 0.0f;
    g_numB = 0.0f;
    g_result = 0.0f;
    g_hasResult = false;
    g_divError = false;
    g_historyExpr.clear();
}

static void Calculate(char op) {
    g_lastOp = op;
    char exprBuf[128];
    std::snprintf(exprBuf, sizeof(exprBuf), "%.3f %c %.3f",
                  static_cast<double>(g_numA), op, static_cast<double>(g_numB));
    g_historyExpr = exprBuf;

    if (op == '/' && std::fabs(g_numB) < 1e-7f) {
        g_divError = true;
        g_hasResult = true;
        return;
    }

    g_divError = false;
    switch (op) {
        case '+': g_result = g_numA + g_numB; break;
        case '-': g_result = g_numA - g_numB; break;
        case '*': g_result = g_numA * g_numB; break;
        case '/': g_result = g_numA / g_numB; break;
    }
    g_hasResult = true;
}

static void RenderUI() {
    ImGuiViewport* viewport = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(viewport->WorkPos);
    ImGui::SetNextWindowSize(viewport->WorkSize);

    ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoBringToFrontOnFocus;

    ImGui::Begin("Calculator", nullptr, flags);

    const float contentWidth = 390.0f;
    const float startX = (ImGui::GetWindowSize().x - contentWidth) * 0.5f;

    ImGui::SetCursorPosY(25.0f);
    ImGui::SetCursorPosX(startX);
    ImGui::Text("�����������");

    ImGui::Separator();
    ImGui::Spacing();

    // ���� �����
    ImGui::SetCursorPosX(startX);
    ImGui::SetNextItemWidth(300.0f);
    ImGui::InputFloat("����� �", &g_numA, 0.0f, 0.0f, "%.3f");

    ImGui::SetCursorPosX(startX);
    ImGui::SetNextItemWidth(300.0f);
    ImGui::InputFloat("����� �", &g_numB, 0.0f, 0.0f, "%.3f");

    ImGui::Spacing();
    ImGui::Spacing();

    // ��� ������: +, -, *, / � C (�����)
    const float btnW = 70.0f;
    const float btnH = 42.0f;
    const float spacingPx = 10.0f;

    ImGui::SetCursorPosX(startX);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(spacingPx, 0));

    if (ImGui::Button("+", ImVec2(btnW, btnH))) Calculate('+');
    ImGui::SameLine();
    if (ImGui::Button("-", ImVec2(btnW, btnH))) Calculate('-');
    ImGui::SameLine();
    if (ImGui::Button("*", ImVec2(btnW, btnH))) Calculate('*');
    ImGui::SameLine();
    if (ImGui::Button("/", ImVec2(btnW, btnH))) Calculate('/');
    ImGui::SameLine();

    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.55f, 0.20f, 0.20f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.70f, 0.25f, 0.25f, 1.0f));
    if (ImGui::Button("C", ImVec2(btnW, btnH))) ClearAll();
    ImGui::PopStyleColor(2);

    ImGui::PopStyleVar();

    // ������� ������� (���� ����� �� ������ ���������� ����)
    if (!ImGui::GetIO().WantTextInput) {
        if (ImGui::IsKeyPressed(ImGuiKey_KeypadAdd)) Calculate('+');
        if (ImGui::IsKeyPressed(ImGuiKey_KeypadSubtract) || ImGui::IsKeyPressed(ImGuiKey_Minus)) Calculate('-');
        if (ImGui::IsKeyPressed(ImGuiKey_KeypadMultiply)) Calculate('*');
        if (ImGui::IsKeyPressed(ImGuiKey_KeypadDivide) || ImGui::IsKeyPressed(ImGuiKey_Slash)) Calculate('/');
        if (ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter)) Calculate(g_lastOp);
        if (ImGui::IsKeyPressed(ImGuiKey_Escape) || ImGui::IsKeyPressed(ImGuiKey_C)) ClearAll();
    }

    ImGui::Spacing();
    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // ���� ����������
    ImGui::SetCursorPosX(startX);
    if (g_hasResult) {
        ImGui::TextDisabled("���������: %s", g_historyExpr.c_str());
        ImGui::SetCursorPosX(startX);

        if (g_divError) {
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.25f, 0.25f, 1.0f));
            ImGui::PushFont(g_fontErr);
            ImGui::TextUnformatted("������: ������� �� ����");
            ImGui::PopFont();
            ImGui::PopStyleColor();
        } else {
            char buf[64];
            std::snprintf(buf, sizeof(buf), "= %.3f", static_cast<double>(g_result));
            ImGui::PushFont(g_fontBig);
            ImGui::TextUnformatted(buf);
            ImGui::PopFont();
        }
    } else {
        ImGui::TextDisabled("������� ����� � �������� �������� (+ - * /)");
    }

    ImGui::End();
}

int main(int, char**) {
    SetupConsoleUtf8();

    if (!glfwInit()) return 1;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE); // ��������� ������ ���� �� ������ GLFW

    GLFWwindow* window = glfwCreateWindow(560, 380, "ImGui Calculator", nullptr, nullptr);
    if (!window) {
        glfwTerminate();
        return 1;
    }

#ifdef _WIN32
    const std::wstring titleW = Utf8ToWide("����������� ImGui");
    SetWindowTextW(glfwGetWin32Window(window), titleW.c_str());
#endif

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; // ��������� �������� ����� imgui.ini ����� � .exe
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.FrameRounding = 6.0f;
    style.FramePadding = ImVec2(10.0f, 6.0f);

    static const ImWchar ranges[] = {
        0x0020, 0x00FF,
        0x2013, 0x2014,
        0x0400, 0x045F,
        0
    };

    const std::string fontPath = GetSystemFontPath("segoeui.ttf");
    g_font = io.Fonts->AddFontFromFileTTF(fontPath.c_str(), 19.0f, nullptr, ranges);
    if (!g_font) g_font = io.Fonts->AddFontDefault();

    g_fontBig = io.Fonts->AddFontFromFileTTF(fontPath.c_str(), 46.0f, nullptr, ranges);
    if (!g_fontBig) g_fontBig = g_font;

    g_fontErr = io.Fonts->AddFontFromFileTTF(fontPath.c_str(), 28.0f, nullptr, ranges);
    if (!g_fontErr) g_fontErr = g_font;

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 130");

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        int displayW, displayH;
        glfwGetFramebufferSize(window, &displayW, &displayH);
        glViewport(0, 0, displayW, displayH);
        glClearColor(0.10f, 0.10f, 0.12f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        RenderUI();

        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
